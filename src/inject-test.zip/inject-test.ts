import 'reflect-metadata';

const instances: any[] = [];

interface Type<T> {
    new (...args: any[]): T;
}

export class Container {
    public static classes: any[] = [];
    private static instances: any[] = [];

    public static get<T>(target: Type<any>): T {
        console.log(target, 'target');

        const params = Reflect.getMetadata('design:paramtypes', target) || [];
        //const injections = params.map((param: any) => Container.get<any>(param));

        return new target();
    }
}

const Service = (): ClassDecorator => {
    return target => {
        console.log(target);

        Container.classes.push(target);
    };
};

/*
function Service<T extends { new (...args: any[]): {} }>(constructor: T) {
    console.log(constructor, 'constructor');

    console.log(Reflect.getMetadata('design:paramtypes', constructor), 'params');

    return class extends constructor {
        test = 'k';
    };
}

/*
const Service = <T extends { new (...args: any[]): {} }>(constructor: T) => {
    console.log(constructor);

    return class extends constructor {
        newProperty = 'new property';
        hello = 'override';
    };

    
    return target => {
        instances.push(target);

        console.log(Reflect.getMetadata('design:paramtypes', target));
    };
};
*/

/*
function InjectService(name: string): any {
    // this is the decorator factory
    return (target: { [key: string]: any }, propertyName: string): void => {
        console.log(target);
    };
}*/
@Service()
class Server {
    private logger: Logger;

    public constructor(logger: Logger) {
        this.logger = logger;
    }

    test() {
        this.logger.log('test');
    }
}

@Service()
class Logger {
    public log(message: string) {
        console.log('logger');
        console.log(message);
    }
}

@Service()
class MyOtherLogger extends Logger {
    public log(message: string) {
        console.log('other logger');
        console.log(message);
    }
}

console.log(Container.classes);

//const server = Container.get<Server>(Server);
//server.test();

//let server = new Server();

//server.test();
