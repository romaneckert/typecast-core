import { Service } from './service';
import { ILogger } from './ilogger';

@Service()
export class Logger implements ILogger {
    public async log(message: string): Promise<void> {
        console.log('log message');
    }
}
