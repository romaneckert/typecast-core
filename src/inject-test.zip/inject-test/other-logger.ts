import { Logger } from './logger';
import { Service } from './service';

@Service()
export class OtherLogger extends Logger {
    public async log(message: string): Promise<void> {
        console.log('log other message');
    }
}
