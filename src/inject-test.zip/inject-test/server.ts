import { Logger } from './logger';
import { Service } from './service';

@Service()
export class Server {
    private logger: Logger;

    public constructor(logger: Logger) {
        this.logger = logger;
    }

    test() {
        this.logger.log('test');
    }
}
