import { OtherLogger } from './other-logger';
import { Service } from './service';
import { Server } from './server';

@Service()
export class ThirdLogger extends OtherLogger {
    public constructor(server: Server) {
        super();
        console.log(server);
    }

    public async log(message: string): Promise<void> {
        console.log('log third message');
    }
}
