import { Container } from './container';

export const Service = (): ClassDecorator => {
    return target => {
        Container.classes.push(target);
    };
};
