import 'reflect-metadata';
import './logger';
import './other-logger';
import './third-logger';

import { Container } from './container';
import { Server } from './server';

const server = Container.get<Server>(Server);
server.test();

interface ITest {}

class Test implements ITest {}

class ExtendTest extends Test {}
