export class Container {
    public static classes: any[] = [];

    public static get<T>(target: any): T {
        let resolvedTarget = target;
        let key: number = -1;

        for (const option of this.classes) {
            if (target.isPrototypeOf(option) || target === option) {
                resolvedTarget = option;
                key++;
            }
        }

        if (-1 === key) {
            throw new Error('can not find class');
        }

        if (undefined !== this.instances[key]) {
            return this.instances[key];
        }

        const params = Reflect.getMetadata('design:paramtypes', resolvedTarget) || [];
        const injections = params.map((param: any) => Container.get<any>(param));

        this.instances[key] = new resolvedTarget(...injections);

        return this.instances[key];
    }

    private static instances: any[] = [];
}
